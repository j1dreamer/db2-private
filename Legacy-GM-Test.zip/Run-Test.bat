@echo off
cd /d "%~dp0"
echo Creates one normal account and tests one +100 normal summon ticket request.
where python >nul 2>&1
if errorlevel 1 (
  py -3 -m venv .venv-legacy-gm
) else (
  python -m venv .venv-legacy-gm
)
if errorlevel 1 goto failed
".venv-legacy-gm\Scripts\python.exe" -m pip install --disable-pip-version-check -r legacy-gm-requirements.txt
if errorlevel 1 goto failed
".venv-legacy-gm\Scripts\python.exe" Test-Legacy-GM.py
if errorlevel 1 goto failed
echo Completed. Read REPORT.json in the output folder.
pause
exit /b 0
:failed
echo Stopped. Read the error above; do not blindly repeat a timed-out GM request.
pause
exit /b 1
