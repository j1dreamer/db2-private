KIEM TRA SERVER CU - TAO TAI KHOAN + THU GM 100 VE

Windows: can Python 3.8+. Giai nen thu muc rieng, chay Run-Test.bat.
Mac/Termux: python -m pip install -r legacy-gm-requirements.txt
           python Test-Legacy-GM.py

May chay tool PHAI truy cap duoc IP server qua Tailscale.
Nhap URL http://IP-TAILSCALE:20003. Nhap ma moi neu server yeu cau.
Tool dang ky mot tai khoan moi, dang nhap, tao nhan vat, doc kho,
gui DUNG MOT request addItem cho 100 ve quay thuong (ID 119),
roi dang nhap lai va so sanh kho. Khong chinh EXP/VIP.
Server tu choi quyen GM thi dung; khong tu cap quyen hay do ma moi.
Khong tu gui lai lenh GM khi timeout vi lenh cu co the da thuc hien.

Tai khoan va mat khau ngau nhien luu o ACCOUNT-PRIVATE.json trong
thu muc ket qua gm-test-*. Giu file nay rieng, KHONG gui len chat.
Chi gui REPORT.json de doi chieu. PASS chi khi kho tang dung 100
sau dang nhap moi; thong bao thanh cong khong du de ket luan.
Moi lan chay tao tai khoan rieng; khong chay lap neu chua doc bao cao.

Neu server khoa theo Android ID cua may ban, dung --device ID_CUA_BAN.
Mac/Termux co the dung python3 thay python. Tool can aiohttp, khong can Node.
Neu server yeu cau protobuf schema, tool dung va bao ro, khong gui GM sai dang.

Chi kiem chung voi backend thu nghiem cuc bo (ca cho phep va tu choi GM).
CHUA tao tai khoan hoac thu GM tren server Tailscale cu tu may Cloud.

iPhone: use iSH Shell, apk add python3 py3-aiohttp curl.
Run --check-only first. Full instructions in IPHONE-GM.md in the repository.

Client version 6 from the APK is now sent on normal /user/ POST requests.
If the backend still rejects old clients, obtain its supported client/protocol.
