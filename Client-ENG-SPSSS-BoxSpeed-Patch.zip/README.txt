DB2 ENG SP/SSS BoxSpeed v3 - Development; native play verification pending.
Use the eng-sp-sss server, build eng-sp-sss-box-speed-v3 (schema 30).
Prefer Download-Clients.zip: it creates full APK/IPA without an old APK.
This patch only accepts the exact fixed APK SHA-256 recorded in plan.json.
New selection-box quantities, cancel X, batch role reward handling.
Speed 1x-10x: compact, draggable, saved position; tap applies immediately.
Do not delete player data. IPA requires legitimate signing separately.
