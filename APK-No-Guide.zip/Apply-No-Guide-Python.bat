@echo off
cd /d "%~dp0"
python apply-no-guide.py
pause
