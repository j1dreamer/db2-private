DB2: Bo qua huong dan / Disable tutorial

1. Giai nen ZIP nay vao mot thu muc rieng.
2. Chep APK dang dung DB2-Private-Android-fixed.apk vao cung thu muc.
3. Chay Apply-No-Guide.bat (hoac Apply-No-Guide-Python.bat).
4. Cai cap nhat DB2-Private-no-guide.apk len gia lap; khong go ban dang dung.
   ADB install -r se giu du lieu ung dung. Server/SQLite khong bi thay doi.

Chi ap dung cho dung APK co SHA256: d3dd3db256d550667eba386217e969327c82cc37985e2b503adea3673f883c3f
APK dau ra SHA256: 93a51856da76adaa1e4229cfd2f12f0756af6bdfb92453eb3e517d8802e22209

Ban nay tat co buildExt.isSkipGuide. Cac chuc nang gameplay chua trien khai van co the tra loi rieng. Khong cap them gem/tuong.
