# Game public và web quản trị HTTPS · v9

Tên miền đã xác nhận: **db2.teck.io.vn**, DNS A trỏ **103.232.122.74**. Game và web dùng cùng hostname; không cần Tailscale cho người chơi sau khi triển khai HTTPS thành công. Trên APK/IPA nhập `https://db2.teck.io.vn` (không thêm `/admin` hoặc `:20003`). Địa chỉ cũ vẫn được lưu trên thiết bị; cần đổi một lần trong nút Server.

## Cài trên Ubuntu VPS

Tải `Setup-Public.sh` từ commit phát hành rồi chạy `sudo bash Setup-Public.sh db2.teck.io.vn` trong phiên SSH của bạn. Script gọi bộ cài Ubuntu ở chế độ `--loopback`, giữ database và backup. Không cần đăng nhập Tailscale trong chế độ này. Nếu gặp một web server hoặc Caddyfile không do DB2 quản lý, script dừng để tránh ghi đè website khác.

Caddy nghe TCP 80/443. Dịch vụ game chỉ nghe `127.0.0.1:20003`, không công khai cổng backend. Nếu UFW đang bật, script thêm luật TCP 80/443; firewall của nhà cung cấp phải cho hai cổng này. DNS A/AAAA phải trỏ đúng máy; không để AAAA cũ trỏ sang máy khác. Với Cloudflare, dùng DNS only trong lần cấp chứng chỉ đầu.

Script chỉ báo HTTPS đã xác minh sau khi `https://db2.teck.io.vn/health` có chứng chỉ hợp lệ và Node combat sẵn sàng, đồng thời `/admin` chưa đăng nhập trả 401. Nếu chưa đạt thì dừng và in hướng dẫn kiểm DNS/chứng chỉ; không yêu cầu bỏ qua lỗi TLS.

## Đăng nhập web

Mở `https://db2.teck.io.vn/admin`:

1. Trình duyệt hỏi username/password của lớp bảo vệ Caddy. Đọc riêng trên VPS: `sudo cat /etc/db2/public-admin-login.json`.
2. Trong giao diện DB2, nhập token quản trị: `sudo cat /var/lib/db2/admin-token`.

Không gửi hai thông tin này vào chat/repo. Username/password được tạo ngẫu nhiên, lưu file mode 600. Caddy chỉ nhận bcrypt hash; không ghi mật khẩu thô vào Caddyfile. Token vẫn kiểm trên mọi API quản trị. Đây là hai lớp kiểm tra, không gọi là xác thực TOTP/2FA.

Web gửi token qua `X-DB2-Admin-Token` để không đụng header `Authorization: Basic` của lớp Caddy. API script đi qua public HTTPS cũng phải cung cấp Basic login và header token này. Bearer cũ vẫn dùng trực tiếp qua loopback/SSH khi không qua Caddy.

Các endpoint game được liệt kê rõ (đăng ký, đăng nhập, cấu hình, báo lỗi, serverInfo, health, WebSocket `/`). Chỉ các endpoint đó đi qua không cần mật khẩu Caddy. `/admin`, tài nguyên quản trị và các đường không thuộc game đều phải đăng nhập. Header `X-Forwarded-For`/`X-DB2-Client-IP` từ bên ngoài không cấp quyền quản trị; ứng dụng kiểm TCP peer thật. Header IP riêng của proxy chỉ dùng đếm giới hạn thử đăng nhập khi proxy chạy loopback và được bật rõ trong env.

Có giới hạn thử đăng ký/đăng nhập, giới hạn số WebSocket, heartbeat/timeout, CSP, chống iframe, nosniff, no-referrer và no-store. Đây là bảo vệ ở ứng dụng/proxy; không phải cam kết chống mọi tấn công hoặc thay bảo vệ lưu lượng của nhà cung cấp.

## Time Peak

Nút Time Peak nổi là màn thử nghiệm do dự án thêm, không phải màn native có sẵn của client ENG. Luật thử gồm đường đi, máu tạm, mượn tướng và chọn blessing. Bản cũ gắn nút vào cả màn chiến đấu và có thể gây thao tác kẹt. PublicReady ẩn mặc định trên APK và IPA; kể cả khi developer bật thử thì chỉ gắn ở sảnh, không trên cảnh chiến đấu. Không xóa dữ liệu hoặc phần thưởng đã lưu của chế độ đó. Các map gameplay khác giữ nguyên.

## Nguồn, kiểm chứng và giới hạn

- Cấu hình theo tài liệu chính thức [Caddy automatic HTTPS](https://caddyserver.com/docs/automatic-https) và [basic_auth](https://caddyserver.com/docs/caddyfile/directives/basic_auth). Basic Auth chỉ dùng trên HTTPS ở production.
- `analysis/public-proxy-integration.json`: chạy Caddy thật, kiểm game không cần mật khẩu web, quản trị thiếu một trong hai credential bị 401, chặn đường mã hóa/traversal và gate trả host/port bên ngoài đúng.
- Kiểm proxy dùng HTTP trên loopback để test routing. Không coi đó là đã cấp/chạy chứng chỉ ACME thật trên VPS.
- APK giữ nguyên native/resources/manifest và chứng thư debug phát triển cũ, kiểm alignment/signature/CRC. IPA giữ sửa plugin khởi động, cần ký lại hợp lệ. Không bỏ kiểm chứng chỉ TLS; bundle CA Android có ISRG Root X1/X2.
- Cloud chưa SSH được vào VPS; DNS đã kiểm trỏ đúng nhưng HTTPS/triển khai thực tế và thao tác native trên iPhone/Android vẫn cần xác minh sau cài.
