DB2 ENG BoxInfo v4 - native play verification pending.
Prefer Download-Clients.zip for full APK/IPA, without an old client.
Use eng-sp-sss server, build eng-sp-sss-box-info-v4, schema 30. Keep existing ENG data.
Box quantities and descriptions follow actual reward config; no fixed x60 override.
Compact draggable Speed 1x-10x. IPA requires legitimate signing separately.
