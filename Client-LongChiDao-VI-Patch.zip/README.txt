DB2 LONG CHI ĐẢO VI - BẢN PHÁT TRIỂN, CHƯA XÁC MINH TRÊN THIẾT BỊ

Độ phủ server: 342/342 route. Đây chưa phải bản chơi đã được xác minh trên thiết bị.
1. Giải nén gói này vào thư mục mới.
2. Chép DB2-Private-Android-fixed.apk đã ghép/cài thành công trước đây vào cùng thư mục.
3. Mở Apply-Dev.bat (PowerShell có sẵn). Hoặc Apply-Dev-Python.bat nếu đã cài Python.
4. Công cụ kiểm SHA-256 trước/sau và tạo DB2-LongChiDao-VI.apk. Không ghép file bằng copy /b.
5. BlueStacks bật Android Debug Bridge, cổng 127.0.0.1:6610. Mở Install-Dev.bat để cài đè và reverse cổng 20003.
6. Server phải dùng source nhánh route-342 và có Node.js LTS + Python. Dừng server cũ, cập nhật source, giữ thư mục data rồi chạy start.bat.

APK cùng package/chứng thư bản fixed, cài đè bằng install -r; không cần gỡ app trước.
Bỏ hướng dẫn; nút Speed góc màn hình chuyển 1x đến 10x cho cả giao diện. Timer/thưởng/ngày dựa trên server.
Đã sửa lỗi màn nền: không gọi setTimeScale khi scheduler còn null lúc nạp bundle.
ADB không thấy máy: kiểm tra cổng trong BlueStacks, sửa 6610 trong Install-Dev.bat nếu cổng đã đổi.
APK/server là nhánh phát triển. Đủ handler không đồng nghĩa mọi luồng gameplay đã được thử trên thiết bị.
Time Peak dùng màn điều khiển và luật riêng vì source gốc thiếu màn hình/bảng blessing/quái.
SHA-256 APK mới: bea64b41319ebba5a84529f644661b13bea85aceed8f775703b642daf686b0ec

Dữ liệu: Long Chi Đảo X7 #17327, 34 bảng + luật khởi động; 3 ID giữ tương thích có nhãn riêng.
Ngôn ngữ: 8.466 mục Việt ENG, 498 mục bổ sung (6 mục sửa), tổng 8.958 khóa.
Mục mới có ghi nguồn, không nhận là bản dịch ENG. Ảnh chữ dựng sẵn ENG vẫn giữ.
Profile schema 29. Backend Python là mã dự án, không phải source server gốc.
Web quản trị: Nguồn và bản dịch; chi tiết item có nguồn dữ liệu/tên/mô tả.
IPA giữ riêng, không nằm trong gói công khai này.
