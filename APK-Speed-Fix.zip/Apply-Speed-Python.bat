@echo off
cd /d "%~dp0"
python apply-speed.py
pause
