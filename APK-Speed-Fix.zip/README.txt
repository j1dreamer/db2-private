DB2 Private: Speed 1x-10x + No Tutorial + Response Error Recovery

1. Extract this ZIP into a separate folder.
2. Copy your DB2-Private-Android-fixed.apk into that folder.
3. Run Apply-Speed.bat, or Apply-Speed-Python.bat.
4. Update-install DB2-Private-speed.apk using ADB install -r.
5. Tap the Speed Nx button near the upper-right corner to cycle 1..10.

Input SHA256: d3dd3db256d550667eba386217e969327c82cc37985e2b503adea3673f883c3f
Output SHA256: 650e472cfbcc821dcb23a280921d1cab863964a0ff22a994aa8fc4177bff5b6f

Keeps the source APK and verifies both hashes. Package and debug certificate
match the old client. Update-install preserves app data. The SQLite server
is separate: update Home-Fix.zip for schema 6 and restart the server.
This patch does not implement missing gameplay routes. Tests are headless;
this build still needs installation and UI verification on BlueStacks.
