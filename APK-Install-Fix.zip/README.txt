SUA LOI CAI APK TREN ANDROID 11+

1. Dat file DB2-Private-Android-dev.apk da ghep vao cung thu muc nay.
2. Can Python 3 (cung Python dung de chay server).
3. Nhap dup Apply-Fix.bat.
4. Doi thong bao Fixed APK created and SHA-256 verified.
5. Cai file moi DB2-Private-Android-fixed.apk vao BlueStacks.

Ban va khong sua file APK goc. Chu ky APK moi da duoc kiem tra v1/v2/v3.
Sua resources.arsc: khong nen, can le 4 byte. Chua xac minh vao sanh tren Android that.
