SUA LOI CAI APK TREN ANDROID 11+

1. Dat file DB2-Private-Android-dev.apk da ghep vao cung thu muc nay.
2. Nhap dup Apply-Fix.bat tren Windows. Dung PowerShell co san, khong can Python.
3. Doi thong bao Fixed APK created and SHA-256 verified.
4. Cai file moi DB2-Private-Android-fixed.apk vao BlueStacks.

Neu dung Python: chay Apply-Fix-Python.bat hoac python apply-apk-fix.py.
Ban va giu nguyen file APK goc. Chu ky APK moi da kiem tra v1/v2/v3.
Sua resources.arsc: khong nen va can le 4 byte. Chua xac minh vao sanh tren BlueStacks that.
