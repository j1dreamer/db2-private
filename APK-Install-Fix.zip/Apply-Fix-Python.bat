@echo off
cd /d "%~dp0"
python apply-apk-fix.py
if errorlevel 1 echo Fix failed. Python 3 is required. Keep the original APK beside this BAT file.
pause
