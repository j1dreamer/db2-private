@echo off
cd /d "%~dp0"
python "%~dp0apply-dev.py"
pause
