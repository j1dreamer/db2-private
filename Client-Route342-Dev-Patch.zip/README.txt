DB2 route-342 - BẢN PHÁT TRIỂN, CHƯA XÁC MINH TRÊN THIẾT BỊ

Độ phủ server: 289/342 route. Đây chưa phải bản hoàn chỉnh.
1. Giải nén gói này vào thư mục mới.
2. Chép DB2-Private-Android-fixed.apk đã ghép/cài thành công trước đây vào cùng thư mục.
3. Mở Apply-Dev.bat (PowerShell có sẵn). Hoặc Apply-Dev-Python.bat nếu đã cài Python.
4. Công cụ kiểm SHA-256 trước/sau và tạo DB2-Private-route342-dev.apk. Không ghép file bằng copy /b.
5. BlueStacks bật Android Debug Bridge, cổng 127.0.0.1:6610. Mở Install-Dev.bat để cài đè và reverse cổng 20003.
6. Server phải dùng source nhánh route-342 và có Node.js LTS + Python. Dừng server cũ, cập nhật source, giữ thư mục data rồi chạy start.bat.

APK cùng package/chứng thư bản fixed, cài đè bằng install -r; không cần gỡ app trước.
Bỏ hướng dẫn; nút Speed góc màn hình chuyển 1x đến 10x cho cả giao diện. Timer/thưởng/ngày dựa trên server.
ADB không thấy máy: kiểm tra cổng trong BlueStacks, sửa 6610 trong Install-Dev.bat nếu cổng đã đổi.
APK/server là nhánh phát triển. Không đổi tên gói này thành bản 342/342.
SHA-256 APK mới: 378fa867f94f12d4e21676bdf74008e4507fe48018aee30bb85d695bb49936a9
