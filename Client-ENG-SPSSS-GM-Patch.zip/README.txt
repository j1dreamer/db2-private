Internal reconstruction recipe for DB2 ENG SSS/SP + GM v2.
Use Download-Clients.bat to download COMPLETE clients; no old APK or manual patching required.
Gameplay source: original ENG. No Long Chi Dao startup/module overrides.
GM UI / transport / Vietnamese / speed / VIP lifecycle and empty reward guards are authored patches.
Native Android/iPhone gameplay remains to be tested on devices.
