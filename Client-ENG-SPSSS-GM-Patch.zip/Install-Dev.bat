@echo off
cd /d "%~dp0"
set "DB2_ADB=C:\Program Files\BlueStacks_polar\HD-Adb.exe"
if not exist "%DB2_ADB%" (
echo Cannot find BlueStacks ADB. Edit the DB2_ADB path in this file.
exit /b 1
)
"%DB2_ADB%" connect 127.0.0.1:6610
"%DB2_ADB%" -s 127.0.0.1:6610 install -r "%~dp0DB2-ENG-SPSSS-GM.apk"
if errorlevel 1 exit /b 1
"%DB2_ADB%" -s 127.0.0.1:6610 reverse tcp:20003 tcp:20003
"%DB2_ADB%" -s 127.0.0.1:6610 reverse --list
pause
